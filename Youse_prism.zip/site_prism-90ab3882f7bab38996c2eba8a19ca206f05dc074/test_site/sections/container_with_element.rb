class ContainerWithElement < SitePrism::Section
  element :embedded_element, '.embedded_element'
end
