class NoElementWithinSection < SitePrism::Section
end
