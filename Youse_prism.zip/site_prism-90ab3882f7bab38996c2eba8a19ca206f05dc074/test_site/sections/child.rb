class Child < SitePrism::Section
  element :nice_label, '.nice-label'
end
