class MyIframe < SitePrism::Page
  element :some_text, 'span#some_text_in_an_iframe'
end
