# frozen_string_literal: true
module SitePrism
  VERSION = '2.8'.freeze
end
